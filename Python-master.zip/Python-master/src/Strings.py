String = " This is a string "
print(String)

# Python Lists.

<img src="https://miro.medium.com/max/1200/1*qv3GbMNNmwCwY50DH6E9WQ.jpeg" >


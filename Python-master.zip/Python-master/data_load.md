# Loading a File using Pandas
## Watch out for different types of file formats!

![Img](https://images.unsplash.com/photo-1504711331083-9c895941bf81?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80)

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FTanu-N-Prabhu%2FPython%2Fblob%2Fmaster%2Fdata_load.md&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://hits.seeyoufarm.com)

| Function    | Description |
| -------- | ------- |
| read_csv  | Read a comma-separated values (CSV) file into DataFrame   |
| read_table | Read general delimited file into DataFrame   |
| read_excel    | $420    |
| read_fwf    | $420    |
| read_clipboard    | $420    |
| read_excel    | $420    |


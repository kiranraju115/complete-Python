str = "example"
str1 = str[3]
print(str1)

str2 = "Tanu"[3]
print(str2)


name = "Tanu"
lastname = "Nanda_Prabhu"
height = 6.1

print("The name of the developer is %s %s and his height is %0.1f" %(name, lastname, height))

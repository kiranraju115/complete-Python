tuple1 = (1, "Hi", True, 8.999)

print(tuple1)

tupleEmpty = ()
print(tupleEmpty)

# Accessing the tuple by Index

tuple2 = (1, 2, 3, 4, 5)

print(tuple2[4])
print(tuple2[1])

# Slicing the tuples

print(tuple2[1:3])
print(tuple2[:3])

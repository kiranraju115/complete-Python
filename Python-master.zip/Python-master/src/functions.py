
def add(c,d):
    e = c + d
    return e


a = int(input("Enter the value of a:"))
b = int(input("Enter the value of b:"))

e = add (a, b)
print(e)

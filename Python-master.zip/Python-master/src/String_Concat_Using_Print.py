String1 = "Tanu"
String2 = "Nanda"
String3 = "Prabhu"

print(String1 + " " + String2 + " " + String3)

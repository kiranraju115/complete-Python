variableNamesCannotBeginWithANumber = True
boolean = True
posInt = 2
zero = 0
negFloat = -1
initial = 3
initial = 4
print(initial)

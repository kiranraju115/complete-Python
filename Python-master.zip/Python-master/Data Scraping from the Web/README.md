# Data Scraping from the Web
<img src="https://i.ytimg.com/vi/4UcqECQe5Kc/maxresdefault.jpg" >

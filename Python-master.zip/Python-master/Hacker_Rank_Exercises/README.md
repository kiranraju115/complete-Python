# This page deals with solved HackerRank exercises. 

<img src="Img/hackerrank.png" >

<p align = "justify"> HackerRank is a technology company that focuses on competitive programming challenges for both consumers and businesses, where developers compete by trying to program according to provided specifications. HackerRank's programming challenges can be solved in a variety of programming languages (including Java, C++, PHP, Python, SQL, JavaScript) and span multiple computer science domains (Copied from Wikipedia). </p>

<h2> Getting started with HackerRank </h2>

1. Sign-In/ Sign-Up: (https://www.hackerrank.com/dashboard).

2. My Profile at HackerRank: (https://www.hackerrank.com/TanuPrabhu)

<p align = "justify"> Configuring HackerRank is quite trivial, but solving problems in it is the most the complicated part (The problems are not straightforward, you have to use your brain). Well, I spend some time everyday in it, just to sharpen my programming skills. I hope even you spend quite some time with it. All the best !!! </p>

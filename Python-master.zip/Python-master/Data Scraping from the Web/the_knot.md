# Pick-Up Lines Scraper Using Beautiful Soup
## This might get you more matches, just kidding!

![Img](https://www.theknot.com/tk-media/images/da179ef1-9c09-43bf-a4ae-4bb116e279d0~rs_768.h)


# Introduction
This article explains you scraping the first 10 pick-up lines 

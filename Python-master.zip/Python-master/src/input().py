firstName = input("Enter your first name")
lastName = input("Enter your last name")
age = input("Enter your age")

print("Your firstname is: %s, lastname is: %s, and height is: %sl" %(firstName, lastName, age))

"""
comments practice:
1.create a single line comment
2.create a multiple line comment
"""

# Hi this me

"""
This is me
"""

"""
basic mathematical operators practice:
1.create a variable called add and assign it the sum of two numbers
2.create a variable called sub and assign it the difference of two numbers
3.create a variable called mult and assign it the product of two numbers
4.create a variable called div and assign it the quotient of two numbers
5.create a variable called power and assign it the value of a number raised to a power
6.create a variable called mod and assign it the emainder of a quotient
"""
add = 5+6
print(add)

sub = 7-6
print(sub)

mult = 9*8
print(mult)

div = 10/2
print(div)

power = 5**6
print(power)

mod = 9%4
print(mod)
"""
modulo practice:
1.create a variable called mod1 and assign it the result of 7 % 5
2.create a variable called mod2 and assign it the result of 16 % 6
3.create a variable called mod3 and assign it the result of 4 % 3
"""
mod1 = 7%5
print(mod1)

mod2 = 16%6
print(mod2)

mod3 = 4%3
print(mod3)
"""
order of operations practice:
1.create and assign a variable called ordOp1 the result of 7 + 6 + 9 - 4 * ((9 - 2) ** 2) / 7
2.create and assign a variable called ordOp2 the result of (6 % 4 * (7 + (7 + 2) * 3)) ** 2
"""

ordOp1 = 7 + 6 + 9 - 4 * ((9 - 2) ** 2) / 7
print(ordOp1)

ordOp2 = (6 % 4 * (7 + (7 + 2) * 3)) ** 2
print(ordOp2)
